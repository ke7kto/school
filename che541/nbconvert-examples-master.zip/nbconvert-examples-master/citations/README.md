# Citation handling for the IPython Notebook

The following Notebooks contain a tutorial and full example showing how to use this capability:

* [Tutorial](http://nbviewer.ipython.org/urls/raw.github.com/ipython/nbconvert-examples/master/citations/Tutorial.ipynb)
* [Full example](http://nbviewer.ipython.org/urls/raw.github.com/ipython/nbconvert-examples/master/citations/Tools%20for%20the%20lifecycle%20of%20computational%20research.ipynb)

Here is the generated PDF of the example that shows how the references look in LaTeX: [download PDF](https://github.com/ipython/nbconvert-examples/raw/master/citations/Tools%20for%20the%20lifecycle%20of%20computational%20research.pdf)