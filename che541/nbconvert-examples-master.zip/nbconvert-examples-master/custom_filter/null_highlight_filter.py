def null_highlight_filter(input, **kwargs):
    return '<pre>'+input+'</pre>'
